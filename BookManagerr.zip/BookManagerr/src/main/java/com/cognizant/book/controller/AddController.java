package com.cognizant.book.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cognizant.book.model.Book;
import com.cognizant.book.service.BookService;

@Controller
@ComponentScan
public class AddController {
                
                @Autowired
                BookService bookService;
                
//            @Autowired(required=true)
//            @Qualifier(value="BookService")
//            public void setBookService(BookService ps){
//                            this.BookService = ps;
//            }
//            
	@RequestMapping(value = "/addBook", method = RequestMethod.GET)
	public String showform(Model model) {

		model.addAttribute("book", new Book());

		// this.bookService.addBookDetails(book);
		return "Add";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String addBook(@ModelAttribute("book") Book book) {

		bookService.addBookDetails(book);
		return "Success";

                }
                             
}