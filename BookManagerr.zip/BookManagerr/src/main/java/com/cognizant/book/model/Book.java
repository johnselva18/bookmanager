package com.cognizant.book.model;

public class Book {
	
	int id;	
	String name;
	String author;
	long number_of_pages;
	String publsh_date;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public long getNumber_of_pages() {
		return number_of_pages;
	}
	public void setNumber_of_pages(long number_of_pages) {
		this.number_of_pages = number_of_pages;
	}
	public String getPublsh_date() {
		return publsh_date;
	}
	public void setPublsh_date(String string) {
		this.publsh_date = string;
	}
	public Book() {
		super();
		this.name = name;
		this.author = author;
		this.number_of_pages = number_of_pages;
		this.publsh_date = publsh_date;
	}

}