package com.cognizant.book.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.book.dao.BookDao;
import com.cognizant.book.model.Book;
@Service
public class BookServiceImpl implements BookService {
	
	@Autowired 
	BookDao bookdao;
	
	public int addBookDetails(Book book) {		
		return this.bookdao.addBookDetails(book);
		
	}

	
	public int updateBookDetails(Book book) {
		// TODO Auto-generated method stub
		return this.bookdao.update(book);
	}

	public Book getBookById(int id) {
		Book book = this.bookdao.getBookById(id);
		 return book;
		}
	
	public int delete(int id) {
		return this.bookdao.delete(id);
		
	}
	
	public List<Book> getBookList() {
		List<Book> list=this.bookdao.getBookList();
		return list;
	}

}
