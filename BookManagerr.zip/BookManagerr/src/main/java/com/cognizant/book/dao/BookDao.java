package com.cognizant.book.dao;

import java.util.List;

import com.cognizant.book.model.Book;

public interface BookDao {
	
	public int addBookDetails(Book book);
	public List<Book> getBookList();
	public Book getBookById(int id);
	public int update(Book book);
	public int delete(int id);
	
}
