package com.cognizant.book.service;


import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cognizant.book.model.Book;

public interface BookService {
	 public int addBookDetails(Book book);
	 public int updateBookDetails(Book book);
	 public List<Book> getBookList();
	public Book getBookById(int id);
	public int delete(int id);
}
