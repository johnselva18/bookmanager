package com.cognizant.book.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.cognizant.book.model.Book;
@Repository
public class BookDaoImpl implements BookDao {

	@Autowired
JdbcTemplate template;    
    
	public void setTemplate(JdbcTemplate template) {    
	    this.template = template;    
	} 
	public int addBookDetails(Book p) {
		 String sql="insert into BOOK(name,author,number_of_pages,publsh_date) values('"+p.getName()+"','"+p.getAuthor()+"',"+p.getNumber_of_pages()+",'"+p.getPublsh_date()+"')";    
		    return template.update(sql);    
	}

	public List<Book> getBookList(){
		return template.query("select * from BOOK",new RowMapper<Book>(){    
	        public Book mapRow(ResultSet rs, int row) throws SQLException {    
	            Book e=new Book();    
	            e.setId(rs.getInt(1));    
	            e.setName(rs.getString(2));    
	            e.setAuthor(rs.getString(3));    
	            e.setNumber_of_pages(rs.getInt(4));
	            e.setPublsh_date(rs.getDate(5).toString());
	            return e;    
	        }    
	    });    	
	}
	
	/*public Book getBookById(int id) {
		String sql="select * from BOOK where book_id=?";    
	    return(Book) template.queryForObject(sql, new Object[]{id},new BeanPropertyRowMapper<Book>(Book.class));    
	}
	*/
	
	public Book getBookById(int id) {
		String sql="select * from BOOK where id= ?";    
	    return template.queryForObject(sql, new Object[]{id},new BeanPropertyRowMapper<Book>(Book.class));  
	}

	public int update(Book p) {
		  String sql="update book set name='"+p.getName()+"', author='"+p.getAuthor()+"',number_of_pages="+p.getNumber_of_pages()+",publsh_date='"+p.getPublsh_date()+"' where id="+p.getId()+""; 
		  return template.update(sql); 
	}
	public int delete(int id) {
		 String sql="delete from book where id="+id+"";    
		    return template.update(sql);    
	}


}