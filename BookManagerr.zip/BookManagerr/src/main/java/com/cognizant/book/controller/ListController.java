package com.cognizant.book.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cognizant.book.model.Book;
import com.cognizant.book.service.BookService;

@Controller
public class ListController
{
@Autowired
 BookService BookService;
          
    @RequestMapping(value="/viewBook")
      public String showEditForm(Model model){  
    	Book book=new Book();
           model.addAttribute("book", book); 
          List<Book> list= this.BookService.getBookList();
          model.addAttribute("listbook", list);
            return "List";   
        }    
   

    
    @RequestMapping(value="/remove/{id}",method = RequestMethod.GET)    
    public String delete(@PathVariable int id){    
        this.BookService.delete(id);    
        return "redirect:/viewBook";    
    }
//	@RequestMapping("/edit")
//	public String editBook(Model model) {
//		
//		return "Update";
//	}
	
	@RequestMapping(value="/editbook/{id}") 
	  public String edit(@PathVariable int id, Model m)
	  { 
		  Book book=this.BookService.getBookById(id); 
		  m.addAttribute("command",book);
		  return "Update"; 
		  }
	
	@RequestMapping(value="/editSave")
	public String editsave(@ModelAttribute("book") Book book)
		  { 
			  this.BookService.updateBookDetails(book);
		  return "Updated"; 
		  }

	
}
